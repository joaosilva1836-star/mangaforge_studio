"""
Implementação concreta dos repositórios usando arquivos JSON em disco.

Simples e 100% offline — adequado para o MVP. Pode ser trocado depois
por SQLite/Postgres implementando as mesmas interfaces em
interfaces/repositories.py, sem tocar nos services.
"""
from __future__ import annotations

import dataclasses
import enum
import json
import os
from typing import Type, TypeVar

from mangaforge_studio.domain.entities import Character, Page, Project, Scene, StyleProfile
from mangaforge_studio.interfaces.repositories import (
    CharacterRepository,
    PageRepository,
    ProjectRepository,
    SceneRepository,
    StyleProfileRepository,
)

T = TypeVar("T")


def _rehydrate_enums(entity_cls: Type, data: dict) -> dict:
    """`json.dump` grava Enums como texto puro; ao recarregar, um dataclass
    comum NÃO reconverte esse texto de volta pro Enum sozinho (Python não
    checa type hints em runtime). Sem isso, `entity.status.value` quebra
    com `AttributeError: 'str' object has no attribute 'value'` assim que
    o objeto é recarregado do disco. Esta função conserta isso genericamente
    pra qualquer dataclass, inspecionando os campos que são Enum.

    Importante: como `domain/entities.py` usa `from __future__ import
    annotations`, os type hints dos campos ficam como STRING (ex:
    "AssetStatus") em vez da classe de verdade — por isso usamos
    `typing.get_type_hints()` pra resolver o tipo real, em vez de
    `isinstance(f.type, type)` (que sempre falha nesse cenário)."""
    import typing

    resolved_hints = typing.get_type_hints(entity_cls)
    data = dict(data)
    for f in dataclasses.fields(entity_cls):
        field_type = resolved_hints.get(f.name, f.type)
        if isinstance(field_type, type) and issubclass(field_type, enum.Enum):
            value = data.get(f.name)
            if value is not None and not isinstance(value, enum.Enum):
                data[f.name] = field_type(value)
    return data


class _JsonRepository:
    """Base genérica: cada entidade vira um arquivo `<id>.json` dentro
    de `base_dir`."""

    entity_cls: Type

    def __init__(self, base_dir: str):
        self._base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def _path(self, entity_id: str) -> str:
        return os.path.join(self._base_dir, f"{entity_id}.json")

    def get(self, entity_id: str):
        path = self._path(entity_id)
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return self.entity_cls(**_rehydrate_enums(self.entity_cls, data))

    def save(self, entity):
        with open(self._path(entity.id), "w", encoding="utf-8") as f:
            json.dump(dataclasses.asdict(entity), f, ensure_ascii=False, indent=2, default=str)
        return entity

    def delete(self, entity_id: str) -> None:
        path = self._path(entity_id)
        if os.path.exists(path):
            os.remove(path)

    def list(self):
        entities = []
        for filename in os.listdir(self._base_dir):
            if filename.endswith(".json"):
                with open(os.path.join(self._base_dir, filename), "r", encoding="utf-8") as f:
                    data = json.load(f)
                entities.append(self.entity_cls(**_rehydrate_enums(self.entity_cls, data)))
        return entities


class JsonCharacterRepository(_JsonRepository, CharacterRepository):
    entity_cls = Character

    def __init__(self, base_dir: str = "./data/characters"):
        super().__init__(base_dir)


class JsonSceneRepository(_JsonRepository, SceneRepository):
    entity_cls = Scene

    def __init__(self, base_dir: str = "./data/scenes"):
        super().__init__(base_dir)


class JsonPageRepository(_JsonRepository, PageRepository):
    """Sobrescreve get/list pois Page contém uma lista aninhada de
    Panel (dataclass); json.load por si só devolveria dicts crus para
    cada panel, então precisamos reidratar manualmente."""

    entity_cls = Page

    def __init__(self, base_dir: str = "./data/pages"):
        super().__init__(base_dir)

    def _hydrate(self, data: dict) -> Page:
        from mangaforge_studio.domain.entities import AssetStatus, Panel

        data = dict(data)
        panels = []
        for p in data.get("panels", []):
            p = dict(p)
            p["status"] = AssetStatus(p.get("status", AssetStatus.DRAFT.value))
            panels.append(Panel(**p))
        data["panels"] = panels
        data["resolution"] = tuple(data.get("resolution", (1024, 1536)))
        data["status"] = AssetStatus(data.get("status", AssetStatus.DRAFT.value))
        return Page(**data)

    def get(self, entity_id: str):
        path = self._path(entity_id)
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return self._hydrate(json.load(f))

    def list(self):
        pages = []
        for filename in os.listdir(self._base_dir):
            if filename.endswith(".json"):
                with open(os.path.join(self._base_dir, filename), "r", encoding="utf-8") as f:
                    pages.append(self._hydrate(json.load(f)))
        return pages


class JsonProjectRepository(_JsonRepository, ProjectRepository):
    entity_cls = Project

    def __init__(self, base_dir: str = "./data/projects"):
        super().__init__(base_dir)


class JsonStyleProfileRepository(_JsonRepository, StyleProfileRepository):
    entity_cls = StyleProfile

    def __init__(self, base_dir: str = "./data/styles"):
        super().__init__(base_dir)
