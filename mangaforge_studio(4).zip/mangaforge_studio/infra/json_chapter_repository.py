"""
Repositório de Chapter.

Guarda só o essencial (id, título, ordem, ids das páginas) — as páginas
em si já vivem no PageRepository, então evitamos duplicar dados. Ao
carregar um Chapter, reidratamos `chapter.pages` buscando cada Page pelo
id no page_repo (garantindo que o status/imagens estejam sempre
atualizados, e não uma cópia congelada de quando o capítulo foi criado).
"""
from __future__ import annotations

import json
import os

from mangaforge_studio.domain.entities import Chapter
from mangaforge_studio.interfaces.repositories import ChapterRepository, PageRepository


class JsonChapterRepository(ChapterRepository):
    def __init__(self, page_repo: PageRepository, base_dir: str = "./data/chapters"):
        self._page_repo = page_repo
        self._base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def _path(self, chapter_id: str) -> str:
        return os.path.join(self._base_dir, f"{chapter_id}.json")

    def _hydrate(self, meta: dict) -> Chapter:
        pages = [self._page_repo.get(pid) for pid in meta.get("page_ids", [])]
        pages = [p for p in pages if p is not None]
        return Chapter(id=meta["id"], title=meta["title"], order=meta.get("order", 1), pages=pages)

    def get(self, entity_id: str) -> Chapter | None:
        path = self._path(entity_id)
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return self._hydrate(json.load(f))

    def save(self, entity: Chapter) -> Chapter:
        meta = {
            "id": entity.id,
            "title": entity.title,
            "order": entity.order,
            "page_ids": [p.id for p in entity.pages],
        }
        with open(self._path(entity.id), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        return entity

    def delete(self, entity_id: str) -> None:
        path = self._path(entity_id)
        if os.path.exists(path):
            os.remove(path)

    def list(self) -> list[Chapter]:
        chapters = []
        for filename in os.listdir(self._base_dir):
            if filename.endswith(".json"):
                with open(os.path.join(self._base_dir, filename), "r", encoding="utf-8") as f:
                    chapters.append(self._hydrate(json.load(f)))
        return chapters
