"""
API REST do MangaForge Studio.

Rodar com:
    uvicorn mangaforge_studio.api.main:app --reload

Swagger disponível automaticamente em /docs (FastAPI gera isso sozinho).

Por padrão usa o MockPipelineFactory (sem GPU) para você testar a API
imediatamente. Para gerar com SDXL de verdade, troque
`USE_MOCK_PIPELINE = False` abaixo (requer GPU NVIDIA + diffusers
instalado).
"""
from __future__ import annotations

from fastapi import FastAPI, HTTPException

from mangaforge_studio.api.schemas import (
    BuildChapterRequest,
    CharacterResponse,
    CreateCharacterRequest,
    ExportChapterRequest,
    GenerateReferenceSheetRequest,
)
from mangaforge_studio.domain.entities import Chapter, ExportFormat
from mangaforge_studio.domain.exceptions import MangaForgeError
from mangaforge_studio.infra.json_repositories import (
    JsonCharacterRepository,
    JsonPageRepository,
    JsonSceneRepository,
    JsonStyleProfileRepository,
)
from mangaforge_studio.infra.page_compositor import PageCompositor
from mangaforge_studio.services.character_service import CharacterService
from mangaforge_studio.services.export_service import ExportService
from mangaforge_studio.services.page_service import PageService
from mangaforge_studio.services.storyboard_service import StoryboardService

USE_MOCK_PIPELINE = True

if USE_MOCK_PIPELINE:
    from mangaforge_studio.infra.mock_pipeline import MockPipelineFactory as _PipelineFactoryImpl
else:
    from mangaforge_studio.infra.diffusion_pipeline import DiffusersPipelineFactory as _PipelineFactoryImpl

app = FastAPI(
    title="MangaForge Studio API",
    description="Geração de personagens, storyboard e páginas de mangá — offline.",
    version="0.1.0",
)

# --- Composição de dependências (Dependency Injection manual e explícita) ---
character_repo = JsonCharacterRepository()
scene_repo = JsonSceneRepository()
page_repo = JsonPageRepository()
style_repo = JsonStyleProfileRepository()
pipeline_factory = _PipelineFactoryImpl()
compositor = PageCompositor()

character_service = CharacterService(character_repo, style_repo, pipeline_factory)
storyboard_service = StoryboardService(scene_repo, page_repo)
page_service = PageService(page_repo, style_repo, pipeline_factory, compositor)
export_service = ExportService()


@app.exception_handler(MangaForgeError)
async def mangaforge_error_handler(request, exc: MangaForgeError):  # noqa: ANN001
    from fastapi.responses import JSONResponse

    return JSONResponse(status_code=400, content={"error": str(exc)})


@app.post("/characters", response_model=CharacterResponse, tags=["characters"])
def create_character(payload: CreateCharacterRequest):
    character = character_service.create_character(
        name=payload.name,
        description=payload.description,
        style_profile_id=payload.style_profile_id,
        seed=payload.seed,
    )
    return CharacterResponse(
        id=character.id,
        name=character.name,
        description=character.description,
        status=character.status.value,
        reference_image_paths=character.reference_image_paths,
    )


@app.post(
    "/characters/{character_id}/reference-sheet",
    response_model=CharacterResponse,
    tags=["characters"],
)
def generate_reference_sheet(character_id: str, payload: GenerateReferenceSheetRequest):
    character = character_service.generate_reference_sheet(character_id, poses=payload.poses)
    return CharacterResponse(
        id=character.id,
        name=character.name,
        description=character.description,
        status=character.status.value,
        reference_image_paths=character.reference_image_paths,
    )


@app.get("/characters/{character_id}", response_model=CharacterResponse, tags=["characters"])
def get_character(character_id: str):
    character = character_repo.get(character_id)
    if character is None:
        raise HTTPException(status_code=404, detail="Character não encontrado")
    return CharacterResponse(
        id=character.id,
        name=character.name,
        description=character.description,
        status=character.status.value,
        reference_image_paths=character.reference_image_paths,
    )


@app.post("/chapters/build", tags=["storyboard"])
def build_chapter(payload: BuildChapterRequest):
    chapter: Chapter = storyboard_service.build_chapter(
        title=payload.title,
        beats=payload.beats,
        order=payload.order,
        panels_per_page=payload.panels_per_page,
    )
    return {
        "chapter_id": chapter.id,
        "title": chapter.title,
        "page_ids": [p.id for p in chapter.pages],
    }


@app.post("/pages/{page_id}/generate", tags=["pages"])
def generate_page(page_id: str, style_profile_id: str | None = None):
    page = page_service.generate_page(page_id, style_profile_id=style_profile_id)
    return {
        "page_id": page.id,
        "status": page.status.value,
        "panel_image_paths": [p.image_path for p in page.panels],
    }


@app.post("/export/{chapter_title}", tags=["export"])
def export_chapter(chapter_title: str, payload: ExportChapterRequest):
    fake_chapter = Chapter(title=chapter_title)
    try:
        fmt = ExportFormat(payload.format)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Formato inválido: {payload.format}")

    output_path = export_service.export(fake_chapter, payload.page_image_paths, fmt)
    return {"output_path": output_path}


@app.get("/health", tags=["system"])
def health():
    return {"status": "ok", "pipeline": "mock" if USE_MOCK_PIPELINE else "diffusers"}
