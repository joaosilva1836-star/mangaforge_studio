# MangaForge Studio

Primeiro módulo implementado do MangaForge AI Enterprise: geração de
**personagens consistentes**, **storyboard**, **páginas de mangá** e
**exportação** (PDF/CBZ/PNG/WEBP). Roda 100% offline.

## Arquitetura (Clean Architecture)

```
mangaforge_studio/
├── domain/          # Entidades puras (Character, Page, Panel, Chapter...) — zero dependências
├── interfaces/       # Contratos abstratos (Repository Pattern, Pipeline)
├── services/         # Lógica de negócio (CharacterService, PageService, StoryboardService, ExportService)
├── infra/             # Implementações concretas (diffusers/SDXL, JSON repos, compositor de página)
├── api/               # FastAPI + Swagger (REST)
└── tests/             # Teste de ponta a ponta com pipeline mock (sem GPU)
```

A regra de dependência do Clean Architecture é respeitada: `domain` não
importa nada; `services` só conhece `interfaces`; `infra` e `api`
implementam/conectam essas interfaces. Isso significa que trocar SDXL
por FLUX, ou trocar o repositório JSON por Postgres, não exige tocar em
nenhuma linha de `services/`.

## Rodando sem GPU (desenvolvimento)

Por padrão a API usa `MockPipelineFactory`, que gera imagens sólidas
com o prompt escrito em cima — serve para testar toda a orquestração
(storyboard → página → export) sem gastar VRAM.

```bash
pip install fastapi uvicorn pydantic pillow
uvicorn mangaforge_studio.api.main:app --reload
# Swagger em http://localhost:8000/docs
```

## Rodando com GPU NVIDIA (produção)

1. Instale as deps completas: `pip install -r requirements.txt`
2. Em `api/main.py`, mude `USE_MOCK_PIPELINE = False`
3. `DiffusersSDXLPipeline` já ativa xFormers automaticamente quando
   disponível (a ativação de Flash Attention/CUDA Graphs e a escolha
   de precisão FP16/BF16 conforme a VRAM ficam a cargo do módulo
   **AI Optimizer**, ainda não implementado — este Studio já foi
   desenhado para receber essa injeção sem mudanças estruturais).

## O que falta implementar (próximos módulos da spec)

- **Hardware Manager**: detecção de GPU/CUDA/VRAM para escolher perfil automaticamente
- **AI Optimizer**: precisão automática, batch size, scheduler/sampler
- **AutoTrainer**: treinamento automático de LoRAs a partir de datasets
- Upscale real (Real-ESRGAN), inpainting/outpainting reais (hoje são stubs em `diffusion_pipeline.py`)
- Vetorização para exportação SVG
- FLUX pipeline (stub em `DiffusersPipelineFactory.create`)

## Testando

```bash
pip install pytest
pytest mangaforge_studio/tests/ -v
```
