"""
Análise de estilo a partir de imagens — nível MVP.

IMPORTANTE (honestidade sobre o escopo): a spec original pede análise
de "traço, sombras, anatomia, perspectiva, personagens, objetos,
cenários, qualidade" — isso, feito de verdade, exige um modelo de visão
computacional treinado (detecção de pose, segmentação, etc). Não temos
esse modelo aqui. O que este módulo faz é uma análise **heurística**,
baseada em processamento de imagem simples com PIL, que aproxima uns
poucos desses sinais (densidade de linhas, contraste, se a imagem é
majoritariamente P&B/tons de tinta). Isso já é útil pra triagem
automática de dataset, mas não substitui um classificador de verdade —
os pontos de extensão pra plugar um modelo real estão marcados abaixo.
"""
from __future__ import annotations

from mangaforge_studio.ingest.entities import StyleAnalysis


class StyleAnalyzer:
    def analyze(self, image_path: str) -> StyleAnalysis | None:
        try:
            from PIL import Image, ImageFilter, ImageStat

            with Image.open(image_path) as img:
                img = img.convert("RGB")
                width, height = img.size

                # Proxy pra "traço": detecta bordas e mede quanto da
                # imagem é ocupado por elas (mais bordas ~ traço mais denso).
                edges = img.convert("L").filter(ImageFilter.FIND_EDGES)
                edge_stat = ImageStat.Stat(edges)
                edge_density = edge_stat.mean[0] / 255.0

                # Proxy pra "sombras"/contraste: desvio padrão do brilho.
                gray_stat = ImageStat.Stat(img.convert("L"))
                avg_brightness = gray_stat.mean[0] / 255.0
                contrast = gray_stat.stddev[0] / 255.0

                # Heurística de "é P&B/tons de tinta": compara canais RGB
                # numa amostra de pixels; se forem quase iguais na maioria,
                # é bem provável que seja preto-e-branco ou tons de cinza
                # (comum em mangá tradicional).
                is_grayscale = self._looks_grayscale(img)

                return StyleAnalysis(
                    width=width,
                    height=height,
                    aspect_ratio=round(width / height, 3) if height else 0.0,
                    is_grayscale_or_inked=is_grayscale,
                    edge_density=round(edge_density, 4),
                    avg_brightness=round(avg_brightness, 4),
                    contrast=round(contrast, 4),
                )
        except Exception:  # noqa: BLE001
            return None

    def _looks_grayscale(self, img) -> bool:
        small = img.resize((32, 32))
        pixels = list(small.getdata())
        close_count = sum(1 for r, g, b in pixels if abs(r - g) < 12 and abs(g - b) < 12)
        return (close_count / len(pixels)) > 0.85

    def build_dataset_summary(self, analyses: list[StyleAnalysis]) -> dict:
        """Agrega várias análises individuais num resumo do dataset
        inteiro — usado pra gerar o 'Perfil de Estilo' automático."""
        valid = [a for a in analyses if a is not None]
        if not valid:
            return {"notes": "Nenhuma imagem analisável no dataset."}

        avg_edge = sum(a.edge_density for a in valid) / len(valid)
        avg_contrast = sum(a.contrast for a in valid) / len(valid)
        pct_grayscale = sum(1 for a in valid if a.is_grayscale_or_inked) / len(valid) * 100

        return {
            "total_images_analisadas": len(valid),
            "densidade_media_de_tracos": round(avg_edge, 4),
            "contraste_medio": round(avg_contrast, 4),
            "percentual_preto_e_branco": round(pct_grayscale, 1),
            "notes": (
                "Perfil heurístico (MVP) — descreve tendências gerais do dataset "
                "(traço, contraste, se predomina P&B). Não substitui uma análise "
                "por modelo de visão treinado especificamente pra estilo de mangá."
            ),
        }

# Extensão futura: plugar um modelo real de análise de estilo aqui
# (ex: um classificador CLIP fine-tuned, ou um extrator de embeddings
# de estilo) substituindo o corpo de `analyze()` mantendo a mesma
# assinatura — o resto do pipeline não precisa mudar nada.
