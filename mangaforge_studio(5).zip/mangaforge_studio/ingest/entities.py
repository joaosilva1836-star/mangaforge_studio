"""
Entidades do MangaForge Import.

Nomeei o pacote de `ingest` em vez de `import` porque `import` é palavra
reservada em Python — não dá pra ter um módulo com esse nome.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional
import uuid


def new_id() -> str:
    return str(uuid.uuid4())


class FileCategory(str, Enum):
    IMAGE = "image"
    MANGA_ARCHIVE = "manga_archive"  # PDF, CBZ, CBR, ZIP
    MODEL = "model"  # safetensors, ckpt, gguf, onnx (checkpoints completos)
    LORA = "lora"  # safetensors especificamente marcados como LoRA
    EMBEDDING = "embedding"  # .pt, .bin
    CONTROLNET = "controlnet"
    VIDEO = "video"
    UNKNOWN = "unknown"


class ImportStatus(str, Enum):
    PENDING = "pending"
    VALID = "valid"
    CORRUPTED = "corrupted"
    DUPLICATE = "duplicate"
    PROCESSED = "processed"
    FAILED = "failed"


@dataclass
class ModelTechnicalInfo:
    """Informações técnicas de um modelo/LoRA/checkpoint importado."""
    architecture: str = "desconhecida"
    format: str = "desconhecido"
    param_count_estimate: Optional[int] = None
    file_size_gb: float = 0.0
    estimated_vram_gb: float = 0.0
    notes: str = ""


@dataclass
class StyleAnalysis:
    """Análise heurística de estilo de uma imagem (nível MVP — sem modelo
    de visão computacional treinado; ver style_analyzer.py pra detalhes
    e pontos de extensão futura)."""
    width: int = 0
    height: int = 0
    aspect_ratio: float = 0.0
    is_grayscale_or_inked: bool = False
    edge_density: float = 0.0  # proxy pra "traço"/densidade de linhas
    avg_brightness: float = 0.0
    contrast: float = 0.0  # proxy pra "sombras"/contraste


@dataclass
class ImportedFile:
    id: str = field(default_factory=new_id)
    original_path: str = ""
    stored_path: str = ""
    category: FileCategory = FileCategory.UNKNOWN
    status: ImportStatus = ImportStatus.PENDING
    size_bytes: int = 0
    sha256: str = ""
    tags: list[str] = field(default_factory=list)
    thumbnail_path: Optional[str] = None
    extracted_page_paths: list[str] = field(default_factory=list)  # p/ PDF/CBZ/CBR
    style_analysis: Optional[StyleAnalysis] = None
    model_info: Optional[ModelTechnicalInfo] = None
    error_message: str = ""
    imported_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class ImportBatchResult:
    """Resumo de uma operação de importação em lote — cobre os dados que
    a spec pediu pra interface mostrar (progresso, velocidade, erros)."""
    total_files: int = 0
    processed: int = 0
    duplicates: int = 0
    corrupted: int = 0
    failed: int = 0
    file_ids: list[str] = field(default_factory=list)
    errors: list[dict] = field(default_factory=list)
    elapsed_seconds: float = 0.0
    files_per_second: float = 0.0


# Mapeamento de extensão -> categoria, conforme a spec.
EXTENSION_MAP: dict[str, FileCategory] = {
    # Imagens
    ".png": FileCategory.IMAGE, ".jpg": FileCategory.IMAGE, ".jpeg": FileCategory.IMAGE,
    ".webp": FileCategory.IMAGE, ".bmp": FileCategory.IMAGE, ".tiff": FileCategory.IMAGE,
    ".tif": FileCategory.IMAGE,
    # Mangás
    ".pdf": FileCategory.MANGA_ARCHIVE, ".cbz": FileCategory.MANGA_ARCHIVE,
    ".cbr": FileCategory.MANGA_ARCHIVE, ".zip": FileCategory.MANGA_ARCHIVE,
    # Modelos
    ".ckpt": FileCategory.MODEL, ".gguf": FileCategory.MODEL, ".onnx": FileCategory.MODEL,
    # .safetensors é ambíguo (pode ser modelo completo OU LoRA) — resolvido
    # dinamicamente pelo tamanho do arquivo em detector.py, não fixo aqui.
    # Embeddings
    ".pt": FileCategory.EMBEDDING, ".bin": FileCategory.EMBEDDING,
    # Vídeos
    ".mp4": FileCategory.VIDEO, ".mkv": FileCategory.VIDEO, ".avi": FileCategory.VIDEO,
}

# Abaixo desse tamanho, um .safetensors é tratado como LoRA; acima, como
# modelo completo. LoRAs tipicamente ficam entre alguns MB e ~1-2GB;
# checkpoints completos (SDXL/FLUX) ficam na casa de 5-24GB.
LORA_SIZE_THRESHOLD_BYTES = 2 * 1024 * 1024 * 1024  # 2GB
