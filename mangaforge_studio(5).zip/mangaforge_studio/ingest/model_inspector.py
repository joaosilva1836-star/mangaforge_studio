"""
Ao importar um modelo/LoRA/checkpoint, identifica arquitetura, formato
e estima a VRAM necessária — sem precisar carregar o modelo inteiro na
memória (o que seria lento e, em modelos de dezenas de GB, inviável só
pra "dar uma olhada").
"""
from __future__ import annotations

import json
import os
import struct

from mangaforge_studio.ingest.entities import ModelTechnicalInfo

# Padrões de nomes de chave que indicam a arquitetura, observados nos
# checkpoints/LoRAs mais comuns do ecossistema Stable Diffusion/FLUX.
_ARCHITECTURE_SIGNATURES = [
    ("double_blocks", "FLUX"),
    ("joint_blocks", "SD3 / MMDiT"),
    ("down_blocks.0.attentions", "SDXL / SD1.5 (UNet)"),
    ("lora_unet", "LoRA (formato Kohya)"),
    ("lora_te", "LoRA (formato Kohya, text encoder)"),
    ("text_model.encoder", "CLIP / Text Encoder"),
    ("controlnet_cond_embedding", "ControlNet"),
]

# Fator aproximado de overhead de VRAM em relação ao tamanho do arquivo
# em disco (pesos + ativações + otimizações de runtime). Number redondo,
# só pra dar uma estimativa útil, não uma medição exata.
_VRAM_OVERHEAD_FACTOR = 1.3


class ModelInspector:
    def inspect(self, path: str, category_hint: str = "") -> ModelTechnicalInfo:
        ext = os.path.splitext(path)[1].lower()
        size_bytes = os.path.getsize(path) if os.path.exists(path) else 0
        size_gb = size_bytes / (1024**3)

        if ext == ".safetensors":
            return self._inspect_safetensors(path, size_gb)
        if ext == ".gguf":
            return self._inspect_gguf(path, size_gb)
        if ext == ".onnx":
            return ModelTechnicalInfo(
                architecture="desconhecida (requer biblioteca onnx pra introspecção completa)",
                format="ONNX",
                file_size_gb=round(size_gb, 2),
                estimated_vram_gb=round(size_gb * _VRAM_OVERHEAD_FACTOR, 2),
                notes="Formato ONNX detectado pela extensão. Introspecção de camadas não implementada neste MVP.",
            )
        if ext == ".ckpt":
            return ModelTechnicalInfo(
                architecture="desconhecida (requer torch.load pra introspecção completa)",
                format="PyTorch checkpoint (pickle/zip)",
                file_size_gb=round(size_gb, 2),
                estimated_vram_gb=round(size_gb * _VRAM_OVERHEAD_FACTOR, 2),
                notes="Arquivo .ckpt detectado. Por segurança, não fazemos unpickling automático "
                "(arquivos .ckpt podem conter código arbitrário) — carregue manualmente com torch se "
                "precisar da arquitetura exata.",
            )

        return ModelTechnicalInfo(
            file_size_gb=round(size_gb, 2),
            estimated_vram_gb=round(size_gb * _VRAM_OVERHEAD_FACTOR, 2),
            notes="Formato não reconhecido pra introspecção detalhada.",
        )

    def _inspect_safetensors(self, path: str, size_gb: float) -> ModelTechnicalInfo:
        try:
            with open(path, "rb") as f:
                header_len = struct.unpack("<Q", f.read(8))[0]
                header = json.loads(f.read(header_len))
        except Exception as exc:  # noqa: BLE001
            return ModelTechnicalInfo(
                format="safetensors",
                file_size_gb=round(size_gb, 2),
                estimated_vram_gb=round(size_gb * _VRAM_OVERHEAD_FACTOR, 2),
                notes=f"Falha ao ler header do safetensors: {exc}",
            )

        keys = [k for k in header.keys() if k != "__metadata__"]
        architecture = "desconhecida"
        joined_keys = " ".join(keys[:200])  # amostra suficiente sem percorrer tudo
        for signature, arch_name in _ARCHITECTURE_SIGNATURES:
            if signature in joined_keys:
                architecture = arch_name
                break

        param_count = 0
        for key, info in header.items():
            if key == "__metadata__":
                continue
            shape = info.get("shape", [])
            n = 1
            for dim in shape:
                n *= dim
            param_count += n

        return ModelTechnicalInfo(
            architecture=architecture,
            format="safetensors",
            param_count_estimate=param_count or None,
            file_size_gb=round(size_gb, 2),
            estimated_vram_gb=round(size_gb * _VRAM_OVERHEAD_FACTOR, 2),
            notes=f"{len(keys)} tensores no header. Arquitetura inferida por assinatura de nomes de camada.",
        )

    def _inspect_gguf(self, path: str, size_gb: float) -> ModelTechnicalInfo:
        try:
            with open(path, "rb") as f:
                magic = f.read(4)
                version = struct.unpack("<I", f.read(4))[0]
                tensor_count = struct.unpack("<Q", f.read(8))[0]
                kv_count = struct.unpack("<Q", f.read(8))[0]
            if magic != b"GGUF":
                raise ValueError("magic bytes inválidos")
            notes = f"GGUF v{version}, {tensor_count} tensores, {kv_count} metadados de KV."
        except Exception as exc:  # noqa: BLE001
            notes = f"Falha ao ler header GGUF: {exc}"

        return ModelTechnicalInfo(
            architecture="GGUF (geralmente LLM quantizado — ver metadados de KV pra detalhes)",
            format="GGUF",
            file_size_gb=round(size_gb, 2),
            estimated_vram_gb=round(size_gb * 1.1, 2),  # GGUF já vem quantizado, overhead menor
            notes=notes,
        )
