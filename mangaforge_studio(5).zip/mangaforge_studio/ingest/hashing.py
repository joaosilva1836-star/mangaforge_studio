"""
Hash de arquivo pra detecção de duplicatas. Lê em blocos (streaming) de
propósito — modelos e checkpoints podem ter vários GB, então carregar o
arquivo inteiro na memória de uma vez seria um desperdício e um risco
de estourar RAM em máquinas mais fracas.
"""
from __future__ import annotations

import hashlib


def sha256_file(path: str, chunk_size: int = 8 * 1024 * 1024) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(chunk_size):
            hasher.update(chunk)
    return hasher.hexdigest()
