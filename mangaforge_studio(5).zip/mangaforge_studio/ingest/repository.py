"""
Índice de arquivos importados, em JSON local — mesmo padrão usado no
resto do MangaForge Studio (offline, sem banco de dados externo).
"""
from __future__ import annotations

import dataclasses
import json
import os
import typing

from mangaforge_studio.ingest.entities import (
    FileCategory,
    ImportedFile,
    ImportStatus,
    ModelTechnicalInfo,
    StyleAnalysis,
)


class ImportedFileRepository:
    def __init__(self, base_dir: str = "./data/imported_files"):
        self._base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def _path(self, file_id: str) -> str:
        return os.path.join(self._base_dir, f"{file_id}.json")

    def save(self, item: ImportedFile) -> ImportedFile:
        with open(self._path(item.id), "w", encoding="utf-8") as f:
            json.dump(dataclasses.asdict(item), f, ensure_ascii=False, indent=2, default=str)
        return item

    def get(self, file_id: str) -> ImportedFile | None:
        path = self._path(file_id)
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return self._hydrate(json.load(f))

    def find_by_sha256(self, sha256: str) -> ImportedFile | None:
        for item in self.list():
            if item.sha256 == sha256:
                return item
        return None

    def list(self, category: FileCategory | None = None) -> list[ImportedFile]:
        items = []
        for filename in os.listdir(self._base_dir):
            if filename.endswith(".json"):
                with open(os.path.join(self._base_dir, filename), "r", encoding="utf-8") as f:
                    item = self._hydrate(json.load(f))
                if category is None or item.category == category:
                    items.append(item)
        return items

    def _hydrate(self, data: dict) -> ImportedFile:
        data = dict(data)
        data["category"] = FileCategory(data.get("category", FileCategory.UNKNOWN.value))
        data["status"] = ImportStatus(data.get("status", ImportStatus.PENDING.value))
        if data.get("style_analysis"):
            data["style_analysis"] = StyleAnalysis(**data["style_analysis"])
        if data.get("model_info"):
            data["model_info"] = ModelTechnicalInfo(**data["model_info"])
        return ImportedFile(**data)
