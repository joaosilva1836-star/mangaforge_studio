"""
Extrai páginas individuais de arquivos de mangá (PDF, CBZ, CBR) e salva
cada uma separadamente, conforme a spec pediu. Balões/textos/OCR ficam
como ponto de extensão (ver nota no fim do arquivo) — a extração de
página em si já é o valor principal dessa etapa.
"""
from __future__ import annotations

import os
import zipfile

_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".tif"}


class ArchiveExtractionError(Exception):
    pass


class ArchiveExtractor:
    def extract(self, path: str, dest_dir: str) -> list[str]:
        ext = os.path.splitext(path)[1].lower()
        os.makedirs(dest_dir, exist_ok=True)

        if ext == ".pdf":
            return self._extract_pdf(path, dest_dir)
        if ext in (".cbz", ".zip"):
            return self._extract_zip_like(path, dest_dir)
        if ext == ".cbr":
            return self._extract_cbr(path, dest_dir)
        raise ArchiveExtractionError(f"Formato não suportado pra extração de páginas: {ext}")

    def _extract_pdf(self, path: str, dest_dir: str) -> list[str]:
        try:
            import fitz  # PyMuPDF
        except ImportError as exc:
            raise ArchiveExtractionError(
                "Extração de PDF requer a biblioteca 'pymupdf' (pip install pymupdf)"
            ) from exc

        pages = []
        with fitz.open(path) as doc:
            for i, page in enumerate(doc, start=1):
                pix = page.get_pixmap(dpi=200)
                out_path = os.path.join(dest_dir, f"page_{i:03d}.png")
                pix.save(out_path)
                pages.append(out_path)
        return pages

    def _extract_zip_like(self, path: str, dest_dir: str) -> list[str]:
        if not zipfile.is_zipfile(path):
            raise ArchiveExtractionError("Arquivo CBZ/ZIP inválido ou corrompido")

        pages = []
        with zipfile.ZipFile(path) as zf:
            image_names = sorted(
                n for n in zf.namelist()
                if os.path.splitext(n)[1].lower() in _IMAGE_EXTENSIONS and not n.startswith("__MACOSX")
            )
            for i, name in enumerate(image_names, start=1):
                ext = os.path.splitext(name)[1].lower()
                out_path = os.path.join(dest_dir, f"page_{i:03d}{ext}")
                with zf.open(name) as src, open(out_path, "wb") as dst:
                    dst.write(src.read())
                pages.append(out_path)
        return pages

    def _extract_cbr(self, path: str, dest_dir: str) -> list[str]:
        try:
            import rarfile  # type: ignore
        except ImportError as exc:
            raise ArchiveExtractionError(
                "Extração de CBR requer a biblioteca 'rarfile' (pip install rarfile) "
                "e o binário 'unrar' instalado no sistema"
            ) from exc

        pages = []
        with rarfile.RarFile(path) as rf:
            image_names = sorted(
                n for n in rf.namelist()
                if os.path.splitext(n)[1].lower() in _IMAGE_EXTENSIONS
            )
            for i, name in enumerate(image_names, start=1):
                ext = os.path.splitext(name)[1].lower()
                out_path = os.path.join(dest_dir, f"page_{i:03d}{ext}")
                with rf.open(name) as src, open(out_path, "wb") as dst:
                    dst.write(src.read())
                pages.append(out_path)
        return pages


# Nota de extensão futura: reconhecimento de balões/quadros e OCR
# ficariam bem aqui como métodos adicionais (`detect_panels`,
# `detect_speech_bubbles`, `ocr_page`), usando um modelo de detecção de
# objetos (ex: YOLO treinado em painéis de mangá) + Tesseract/PaddleOCR
# pro texto. Não implementado neste MVP pra manter o escopo focado na
# extração de páginas, que é a base de tudo o resto.
