from __future__ import annotations

import os
import uuid


class ThumbnailGenerator:
    def __init__(self, output_dir: str = "./Projetos/.thumbnails", size: tuple[int, int] = (256, 256)):
        self._output_dir = output_dir
        self._size = size
        os.makedirs(output_dir, exist_ok=True)

    def generate_from_image(self, image_path: str) -> str | None:
        try:
            from PIL import Image

            with Image.open(image_path) as img:
                img = img.convert("RGB")
                img.thumbnail(self._size)
                out_path = os.path.join(self._output_dir, f"{uuid.uuid4()}.jpg")
                img.save(out_path, "JPEG", quality=85)
                return out_path
        except Exception:  # noqa: BLE001
            return None  # miniatura é "nice to have", nunca deve derrubar a importação
