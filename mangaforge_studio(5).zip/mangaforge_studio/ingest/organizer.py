"""
Cria e mantém a estrutura de pastas `Projetos/` definida na spec, e
organiza cada arquivo importado na subpasta certa conforme sua
categoria.
"""
from __future__ import annotations

import os
import shutil

from mangaforge_studio.ingest.entities import FileCategory

_CATEGORY_TO_SUBDIR = {
    FileCategory.IMAGE: "Dataset",
    FileCategory.MANGA_ARCHIVE: "Mangás",
    FileCategory.MODEL: "Modelos",
    FileCategory.LORA: "LoRAs",
    FileCategory.EMBEDDING: "Modelos",
    FileCategory.CONTROLNET: "Modelos",
    FileCategory.VIDEO: "Dataset",
    FileCategory.UNKNOWN: "Logs",  # arquivos não reconhecidos vão pra Logs, não se perdem
}

_FIXED_SUBDIRS = [
    "Dataset", "Modelos", "LoRAs", "Estilos", "Mangás",
    "Export", "Treinamentos", "Logs", "Backup",
]


class FileOrganizer:
    def __init__(self, base_dir: str = "./Projetos"):
        self._base_dir = base_dir
        self._ensure_structure()

    def _ensure_structure(self) -> None:
        for subdir in _FIXED_SUBDIRS:
            os.makedirs(os.path.join(self._base_dir, subdir), exist_ok=True)

    def subdir_for(self, category: FileCategory) -> str:
        return os.path.join(self._base_dir, _CATEGORY_TO_SUBDIR.get(category, "Logs"))

    def organize(self, source_path: str, category: FileCategory, unique_suffix: str = "") -> str:
        """Copia o arquivo (não move — preserva o original do usuário)
        pra dentro da subpasta certa. Em caso de nome já existente,
        acrescenta um sufixo curto pra não sobrescrever nada."""
        dest_dir = self.subdir_for(category)
        filename = os.path.basename(source_path)
        dest_path = os.path.join(dest_dir, filename)

        if os.path.exists(dest_path):
            name, ext = os.path.splitext(filename)
            suffix = unique_suffix or "dup"
            dest_path = os.path.join(dest_dir, f"{name}_{suffix}{ext}")

        shutil.copy2(source_path, dest_path)
        return dest_path
