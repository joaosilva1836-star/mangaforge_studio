"""
Detecta a categoria de um arquivo — primeiro pela extensão (rápido),
com uma checagem leve de assinatura binária pra evitar erros óbvios de
extensão trocada (ex: um .png que na verdade é um zip renomeado).
"""
from __future__ import annotations

import os
import zipfile

from mangaforge_studio.ingest.entities import EXTENSION_MAP, LORA_SIZE_THRESHOLD_BYTES, FileCategory

# Assinaturas binárias (magic bytes) conhecidas, pra validação rápida.
_MAGIC_BYTES = {
    b"\x89PNG\r\n\x1a\n": FileCategory.IMAGE,
    b"\xff\xd8\xff": FileCategory.IMAGE,  # JPEG
    b"BM": FileCategory.IMAGE,  # BMP
    b"RIFF": None,  # WEBP (RIFF) ou AVI (RIFF) — desambiguado depois
    b"II*\x00": FileCategory.IMAGE,  # TIFF little-endian
    b"MM\x00*": FileCategory.IMAGE,  # TIFF big-endian
    b"%PDF": FileCategory.MANGA_ARCHIVE,
    b"PK\x03\x04": None,  # ZIP/CBZ/safetensors-like — desambiguado por extensão
    b"Rar!\x1a\x07": FileCategory.MANGA_ARCHIVE,  # CBR (RAR)
    b"GGUF": FileCategory.MODEL,
    b"\x1aE\xdf\xa3": FileCategory.VIDEO,  # MKV (EBML header)
}


class FileTypeDetector:
    def detect(self, path: str) -> FileCategory:
        ext = os.path.splitext(path)[1].lower()

        if ext == ".safetensors":
            return self._classify_safetensors(path)

        category = EXTENSION_MAP.get(ext)
        if category is not None:
            return category

        return self._detect_by_magic_bytes(path)

    def _classify_safetensors(self, path: str) -> FileCategory:
        """.safetensors pode ser LoRA ou modelo completo — desambigua
        pelo tamanho do arquivo (heurística simples e rápida, sem
        precisar carregar os tensores)."""
        try:
            size = os.path.getsize(path)
        except OSError:
            return FileCategory.LORA  # assume o caso mais comum se não conseguir ler
        return FileCategory.LORA if size < LORA_SIZE_THRESHOLD_BYTES else FileCategory.MODEL

    def _detect_by_magic_bytes(self, path: str) -> FileCategory:
        try:
            with open(path, "rb") as f:
                header = f.read(16)
        except OSError:
            return FileCategory.UNKNOWN

        for magic, category in _MAGIC_BYTES.items():
            if header.startswith(magic):
                if category is not None:
                    return category
                # Casos ambíguos: RIFF (webp/avi) e PK (zip/cbz)
                if magic == b"RIFF":
                    return FileCategory.IMAGE if b"WEBP" in header else FileCategory.VIDEO
                if magic == b"PK\x03\x04":
                    return FileCategory.MANGA_ARCHIVE if zipfile.is_zipfile(path) else FileCategory.UNKNOWN

        return FileCategory.UNKNOWN
