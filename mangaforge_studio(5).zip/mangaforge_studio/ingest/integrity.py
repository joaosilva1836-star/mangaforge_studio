"""
Checa se um arquivo está íntegro (não corrompido) antes de organizá-lo.
Cada categoria tem sua própria checagem, sem depender de bibliotecas
pesadas — só o suficiente pra pegar os casos mais comuns de corrupção
(arquivo truncado, header inválido, zip quebrado etc).
"""
from __future__ import annotations

import os
import struct
import zipfile


class IntegrityChecker:
    def check(self, path: str, category) -> tuple[bool, str]:
        """Retorna (ok, motivo). Se ok=False, `motivo` explica o problema."""
        from mangaforge_studio.ingest.entities import FileCategory

        if not os.path.exists(path):
            return False, "Arquivo não encontrado"
        if os.path.getsize(path) == 0:
            return False, "Arquivo vazio (0 bytes)"

        checkers = {
            FileCategory.IMAGE: self._check_image,
            FileCategory.MANGA_ARCHIVE: self._check_manga_archive,
            FileCategory.MODEL: self._check_model,
            FileCategory.LORA: self._check_model,
            FileCategory.EMBEDDING: self._check_embedding,
            FileCategory.CONTROLNET: self._check_model,
            FileCategory.VIDEO: self._check_video,
        }
        checker = checkers.get(category)
        if checker is None:
            return True, "Sem checagem específica pra essa categoria (assumido OK)"
        return checker(path)

    def _check_image(self, path: str) -> tuple[bool, str]:
        try:
            from PIL import Image

            with Image.open(path) as img:
                img.verify()  # checa a estrutura sem decodificar tudo
            return True, ""
        except Exception as exc:  # noqa: BLE001
            return False, f"Imagem corrompida ou formato inválido: {exc}"

    def _check_manga_archive(self, path: str) -> tuple[bool, str]:
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == ".pdf":
                with open(path, "rb") as f:
                    header = f.read(5)
                if not header.startswith(b"%PDF-"):
                    return False, "Header de PDF inválido"
                return True, ""
            if ext in (".cbz", ".zip"):
                if not zipfile.is_zipfile(path):
                    return False, "Arquivo ZIP/CBZ corrompido"
                with zipfile.ZipFile(path) as zf:
                    bad_file = zf.testzip()
                    if bad_file is not None:
                        return False, f"Entrada corrompida dentro do zip: {bad_file}"
                return True, ""
            if ext == ".cbr":
                try:
                    import rarfile  # type: ignore

                    with rarfile.RarFile(path) as rf:
                        bad = rf.testrar()
                        if bad is not None:
                            return False, f"Entrada corrompida dentro do RAR: {bad}"
                    return True, ""
                except ImportError:
                    return True, "CBR: biblioteca 'rarfile' não instalada — checagem de integridade pulada"
            return True, ""
        except Exception as exc:  # noqa: BLE001
            return False, f"Falha ao verificar arquivo de mangá: {exc}"

    def _check_model(self, path: str) -> tuple[bool, str]:
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == ".safetensors":
                with open(path, "rb") as f:
                    header_len_bytes = f.read(8)
                    if len(header_len_bytes) < 8:
                        return False, "Arquivo .safetensors truncado (header incompleto)"
                    header_len = struct.unpack("<Q", header_len_bytes)[0]
                    if header_len <= 0 or header_len > os.path.getsize(path):
                        return False, "Tamanho de header inválido em .safetensors — arquivo corrompido"
                    header_bytes = f.read(header_len)
                    if len(header_bytes) < header_len:
                        return False, "Arquivo .safetensors truncado (dados incompletos)"
                    import json

                    json.loads(header_bytes)  # deve ser JSON válido
                return True, ""
            if ext == ".gguf":
                with open(path, "rb") as f:
                    magic = f.read(4)
                if magic != b"GGUF":
                    return False, "Magic bytes inválidos — não é um arquivo GGUF válido"
                return True, ""
            if ext == ".onnx":
                # Protobuf não tem magic bytes fixos simples; checagem básica de tamanho mínimo.
                if os.path.getsize(path) < 16:
                    return False, "Arquivo .onnx pequeno demais pra ser válido"
                return True, ""
            if ext == ".ckpt":
                # .ckpt é um pickle/zip do PyTorch; sem torch instalado só
                # validamos que abre como zip (checkpoints modernos usam zip).
                if zipfile.is_zipfile(path):
                    return True, ""
                return True, "Formato .ckpt legado (pickle puro) — checagem completa requer torch.load"
            return True, ""
        except Exception as exc:  # noqa: BLE001
            return False, f"Falha ao verificar modelo: {exc}"

    def _check_embedding(self, path: str) -> tuple[bool, str]:
        # .pt/.bin são geralmente pickles do PyTorch; sem torch, só
        # confirmamos que o arquivo não está vazio (já checado acima).
        return True, "Checagem completa de .pt/.bin requer torch.load (pulada aqui)"

    def _check_video(self, path: str) -> tuple[bool, str]:
        try:
            with open(path, "rb") as f:
                header = f.read(12)
            if header[4:8] == b"ftyp":  # MP4/MOV
                return True, ""
            if header[:4] == b"\x1aE\xdf\xa3":  # MKV
                return True, ""
            if header[:4] == b"RIFF" and header[8:12] == b"AVI ":
                return True, ""
            return False, "Header de vídeo não reconhecido — arquivo pode estar corrompido ou truncado"
        except Exception as exc:  # noqa: BLE001
            return False, f"Falha ao verificar vídeo: {exc}"
