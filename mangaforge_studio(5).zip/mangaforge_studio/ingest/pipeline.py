"""
Orquestra o fluxo completo de importação: detectar -> checar integridade
-> checar duplicata -> organizar -> gerar miniatura/metadados -> extrair
páginas (se mangá) -> analisar estilo (se imagem) -> indexar.

É o único ponto de entrada que a API precisa conhecer — por trás dele
ficam escondidos o detector, o hasher, o organizador, etc (Facade
Pattern, no espírito do Service Layer que a spec original pediu).
"""
from __future__ import annotations

import os
import time

from mangaforge_studio.ingest.archive_extractor import ArchiveExtractionError, ArchiveExtractor
from mangaforge_studio.ingest.detector import FileTypeDetector
from mangaforge_studio.ingest.entities import (
    FileCategory,
    ImportBatchResult,
    ImportedFile,
    ImportStatus,
)
from mangaforge_studio.ingest.hashing import sha256_file
from mangaforge_studio.ingest.integrity import IntegrityChecker
from mangaforge_studio.ingest.model_inspector import ModelInspector
from mangaforge_studio.ingest.organizer import FileOrganizer
from mangaforge_studio.ingest.repository import ImportedFileRepository
from mangaforge_studio.ingest.style_analyzer import StyleAnalyzer
from mangaforge_studio.ingest.thumbnails import ThumbnailGenerator

# Extensões reconhecidas em algum ponto do sistema — usado só pra pular
# rapidamente arquivos de sistema/irrelevantes ao varrer uma pasta.
_IGNORED_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}


class ImportPipeline:
    def __init__(
        self,
        repository: ImportedFileRepository,
        organizer: FileOrganizer,
        thumbnail_generator: ThumbnailGenerator,
        detector: FileTypeDetector | None = None,
        integrity_checker: IntegrityChecker | None = None,
        model_inspector: ModelInspector | None = None,
        style_analyzer: StyleAnalyzer | None = None,
        archive_extractor: ArchiveExtractor | None = None,
    ):
        self._repo = repository
        self._organizer = organizer
        self._thumbnails = thumbnail_generator
        self._detector = detector or FileTypeDetector()
        self._integrity = integrity_checker or IntegrityChecker()
        self._model_inspector = model_inspector or ModelInspector()
        self._style_analyzer = style_analyzer or StyleAnalyzer()
        self._archive_extractor = archive_extractor or ArchiveExtractor()

    def import_file(self, path: str) -> ImportedFile:
        """Processa um único arquivo. Nunca levanta exceção pra cima —
        qualquer falha vira um ImportedFile com status FAILED/CORRUPTED,
        pra não derrubar uma importação em lote por causa de um arquivo
        problemático."""
        item = ImportedFile(original_path=path)

        try:
            item.size_bytes = os.path.getsize(path)
            item.category = self._detector.detect(path)

            ok, reason = self._integrity.check(path, item.category)
            if not ok:
                item.status = ImportStatus.CORRUPTED
                item.error_message = reason
                self._repo.save(item)
                return item

            item.sha256 = sha256_file(path)
            duplicate = self._repo.find_by_sha256(item.sha256)
            if duplicate is not None:
                item.status = ImportStatus.DUPLICATE
                item.error_message = f"Duplicata do arquivo já importado (id original: {duplicate.id})"
                self._repo.save(item)
                return item

            stored_path = self._organizer.organize(path, item.category, unique_suffix=item.id[:8])
            item.stored_path = stored_path

            self._enrich(item)

            item.status = ImportStatus.PROCESSED
        except Exception as exc:  # noqa: BLE001
            item.status = ImportStatus.FAILED
            item.error_message = str(exc)

        self._repo.save(item)
        return item

    def _enrich(self, item: ImportedFile) -> None:
        """Gera miniatura, metadados, análise de estilo e extração de
        páginas — o que for aplicável pra categoria do arquivo."""
        if item.category == FileCategory.IMAGE:
            item.thumbnail_path = self._thumbnails.generate_from_image(item.stored_path)
            item.style_analysis = self._style_analyzer.analyze(item.stored_path)
            item.tags = self._auto_tags_image(item)

        elif item.category in (FileCategory.MODEL, FileCategory.LORA, FileCategory.CONTROLNET):
            item.model_info = self._model_inspector.inspect(item.stored_path)
            item.tags = [item.category.value, item.model_info.architecture]

        elif item.category == FileCategory.MANGA_ARCHIVE:
            pages_dir = os.path.join(os.path.dirname(item.stored_path), f"{item.id}_pages")
            try:
                item.extracted_page_paths = self._archive_extractor.extract(item.stored_path, pages_dir)
                if item.extracted_page_paths:
                    item.thumbnail_path = self._thumbnails.generate_from_image(item.extracted_page_paths[0])
                item.tags = ["manga", f"{len(item.extracted_page_paths)}_paginas"]
            except ArchiveExtractionError as exc:
                item.error_message = str(exc)  # organizado mesmo assim, só sem páginas extraídas

        elif item.category == FileCategory.EMBEDDING:
            item.tags = ["embedding"]

        elif item.category == FileCategory.VIDEO:
            item.tags = ["video"]

    def _auto_tags_image(self, item: ImportedFile) -> list[str]:
        tags = ["imagem"]
        if item.style_analysis:
            if item.style_analysis.is_grayscale_or_inked:
                tags.append("preto-e-branco")
            else:
                tags.append("colorido")
            if item.style_analysis.edge_density > 0.15:
                tags.append("traco-denso")
            if item.style_analysis.width >= 2000 or item.style_analysis.height >= 2000:
                tags.append("alta-resolucao")
        return tags

    def scan_directory(self, root_path: str) -> ImportBatchResult:
        """Varre uma pasta inteira recursivamente e importa cada
        arquivo reconhecido — é o que atende ao requisito de 'pastas
        completas' da spec."""
        start = time.time()
        result = ImportBatchResult()

        all_paths = []
        for dirpath, _dirnames, filenames in os.walk(root_path):
            for filename in filenames:
                if filename in _IGNORED_NAMES or filename.startswith("."):
                    continue
                all_paths.append(os.path.join(dirpath, filename))

        result.total_files = len(all_paths)

        for path in all_paths:
            try:
                item = self.import_file(path)
                result.file_ids.append(item.id)
                if item.status == ImportStatus.PROCESSED:
                    result.processed += 1
                elif item.status == ImportStatus.DUPLICATE:
                    result.duplicates += 1
                elif item.status == ImportStatus.CORRUPTED:
                    result.corrupted += 1
                elif item.status == ImportStatus.FAILED:
                    result.failed += 1
                    result.errors.append({"path": path, "error": item.error_message})
            except Exception as exc:  # noqa: BLE001
                result.failed += 1
                result.errors.append({"path": path, "error": str(exc)})

        result.elapsed_seconds = round(time.time() - start, 3)
        result.files_per_second = (
            round(result.total_files / result.elapsed_seconds, 2) if result.elapsed_seconds > 0 else 0.0
        )
        return result
