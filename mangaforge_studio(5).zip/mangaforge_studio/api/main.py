"""
API REST do MangaForge Studio.

Rodar com:
    uvicorn mangaforge_studio.api.main:app --reload

Swagger disponível automaticamente em /docs (FastAPI gera isso sozinho).

Por padrão usa o MockPipelineFactory (sem GPU) para você testar a API
imediatamente. Para gerar com SDXL de verdade, troque
`USE_MOCK_PIPELINE = False` abaixo (requer GPU NVIDIA + diffusers
instalado).
"""
from __future__ import annotations

import dataclasses
import os

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from mangaforge_studio.api.schemas import (
    BuildChapterRequest,
    CharacterResponse,
    CreateCharacterRequest,
    ExportChapterAutoRequest,
    ExportChapterRequest,
    GenerateReferenceSheetRequest,
    ImportScanRequest,
)
from mangaforge_studio.domain.entities import Chapter, ExportFormat
from mangaforge_studio.domain.exceptions import MangaForgeError
from mangaforge_studio.hardware.detector import HardwareDetector
from mangaforge_studio.hardware.optimizer import AIOptimizer
from mangaforge_studio.infra.json_chapter_repository import JsonChapterRepository
from mangaforge_studio.infra.json_repositories import (
    JsonCharacterRepository,
    JsonPageRepository,
    JsonSceneRepository,
    JsonStyleProfileRepository,
)
from mangaforge_studio.infra.page_compositor import PageCompositor
from mangaforge_studio.ingest.entities import FileCategory
from mangaforge_studio.ingest.organizer import FileOrganizer
from mangaforge_studio.ingest.pipeline import ImportPipeline
from mangaforge_studio.ingest.repository import ImportedFileRepository
from mangaforge_studio.ingest.thumbnails import ThumbnailGenerator
from mangaforge_studio.services.character_service import CharacterService
from mangaforge_studio.services.export_service import ExportService
from mangaforge_studio.services.page_service import PageService
from mangaforge_studio.services.storyboard_service import StoryboardService

USE_MOCK_PIPELINE = True

if USE_MOCK_PIPELINE:
    from mangaforge_studio.infra.mock_pipeline import MockPipelineFactory as _PipelineFactoryImpl
else:
    from mangaforge_studio.infra.diffusion_pipeline import DiffusersPipelineFactory as _PipelineFactoryImpl

app = FastAPI(
    title="MangaForge Studio API",
    description="Geração de personagens, storyboard e páginas de mangá — offline.",
    version="0.1.0",
)

# Libera acesso de qualquer origem (necessário pro frontend rodar fora da pod,
# ex: aberto localmente no seu navegador). Em produção, restrinja a origins
# específicas em vez de "*".
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs("output", exist_ok=True)
app.mount("/files", StaticFiles(directory="output"), name="files")

os.makedirs("Projetos", exist_ok=True)
app.mount("/projetos", StaticFiles(directory="Projetos"), name="projetos")


def to_public_url(local_path: str | None) -> str | None:
    """Converte um caminho local numa URL servível pelo servidor de
    arquivos estáticos certo (/files pra saídas de geração, /projetos
    pra arquivos organizados pelo MangaForge Import)."""
    if not local_path:
        return local_path
    normalized = local_path.replace("\\", "/")
    for marker, mount in (("output/", "/files/"), ("Projetos/", "/projetos/")):
        if marker in normalized:
            return mount + normalized.split(marker, 1)[1]
    return local_path

# --- Hardware Manager + AI Optimizer: roda uma vez na subida da API ---
hardware_detector = HardwareDetector()
ai_optimizer = AIOptimizer()
detected_system = hardware_detector.detect()
hardware_profile = ai_optimizer.recommend_profile(detected_system)
print("[Hardware Manager]", ai_optimizer.explain(detected_system, hardware_profile))

# --- Composição de dependências (Dependency Injection manual e explícita) ---
character_repo = JsonCharacterRepository()
scene_repo = JsonSceneRepository()
page_repo = JsonPageRepository()
style_repo = JsonStyleProfileRepository()
chapter_repo = JsonChapterRepository(page_repo=page_repo)

if USE_MOCK_PIPELINE:
    pipeline_factory = _PipelineFactoryImpl()
else:
    pipeline_factory = _PipelineFactoryImpl(hardware_profile=hardware_profile)

compositor = PageCompositor()

character_service = CharacterService(character_repo, style_repo, pipeline_factory)
storyboard_service = StoryboardService(scene_repo, page_repo, chapter_repo)
page_service = PageService(page_repo, style_repo, pipeline_factory, compositor)
export_service = ExportService()

# --- MangaForge Import ---
import_repo = ImportedFileRepository()
file_organizer = FileOrganizer(base_dir="./Projetos")
thumbnail_generator = ThumbnailGenerator(output_dir="./Projetos/.thumbnails")
import_pipeline = ImportPipeline(import_repo, file_organizer, thumbnail_generator)


@app.exception_handler(MangaForgeError)
async def mangaforge_error_handler(request, exc: MangaForgeError):  # noqa: ANN001
    from fastapi.responses import JSONResponse

    return JSONResponse(status_code=400, content={"error": str(exc)})


@app.post("/characters", response_model=CharacterResponse, tags=["characters"])
def create_character(payload: CreateCharacterRequest):
    character = character_service.create_character(
        name=payload.name,
        description=payload.description,
        style_profile_id=payload.style_profile_id,
        seed=payload.seed,
    )
    return CharacterResponse(
        id=character.id,
        name=character.name,
        description=character.description,
        status=character.status.value,
        reference_image_paths=[to_public_url(p) for p in character.reference_image_paths],
    )


@app.post(
    "/characters/{character_id}/reference-sheet",
    response_model=CharacterResponse,
    tags=["characters"],
)
def generate_reference_sheet(character_id: str, payload: GenerateReferenceSheetRequest):
    character = character_service.generate_reference_sheet(character_id, poses=payload.poses)
    return CharacterResponse(
        id=character.id,
        name=character.name,
        description=character.description,
        status=character.status.value,
        reference_image_paths=[to_public_url(p) for p in character.reference_image_paths],
    )


@app.get("/characters/{character_id}", response_model=CharacterResponse, tags=["characters"])
def get_character(character_id: str):
    character = character_repo.get(character_id)
    if character is None:
        raise HTTPException(status_code=404, detail="Character não encontrado")
    return CharacterResponse(
        id=character.id,
        name=character.name,
        description=character.description,
        status=character.status.value,
        reference_image_paths=[to_public_url(p) for p in character.reference_image_paths],
    )


@app.post("/chapters/build", tags=["storyboard"])
def build_chapter(payload: BuildChapterRequest):
    chapter: Chapter = storyboard_service.build_chapter(
        title=payload.title,
        beats=payload.beats,
        order=payload.order,
        panels_per_page=payload.panels_per_page,
    )
    return {
        "chapter_id": chapter.id,
        "title": chapter.title,
        "page_ids": [p.id for p in chapter.pages],
    }


@app.post("/pages/{page_id}/generate", tags=["pages"])
def generate_page(page_id: str, style_profile_id: str | None = None):
    page = page_service.generate_page(page_id, style_profile_id=style_profile_id)
    return {
        "page_id": page.id,
        "status": page.status.value,
        "panel_image_paths": [to_public_url(p.image_path) for p in page.panels],
        "composed_page_url": to_public_url(f"./output/pages/page_{page.page_number}.png"),
    }


@app.post("/export/{chapter_title}", tags=["export"])
def export_chapter(chapter_title: str, payload: ExportChapterRequest):
    """Export manual: você mesmo informa os caminhos das páginas já
    compostas. Prefira /chapters/{chapter_id}/export para o fluxo
    automático (recomendado)."""
    fake_chapter = Chapter(title=chapter_title)
    try:
        fmt = ExportFormat(payload.format)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Formato inválido: {payload.format}")

    output_path = export_service.export(fake_chapter, payload.page_image_paths, fmt)
    return {"output_path": output_path, "download_url": to_public_url(output_path)}


@app.post("/chapters/{chapter_id}/export", tags=["export"])
def export_chapter_auto(chapter_id: str, payload: ExportChapterAutoRequest):
    """Export automático: não precisa colar nenhum caminho de imagem.
    Pega o capítulo pelo id, gera sozinho qualquer página que ainda não
    tenha sido renderizada, e já devolve o link de download do arquivo
    final (CBZ/PDF/PNG/WEBP)."""
    chapter = chapter_repo.get(chapter_id)
    if chapter is None:
        raise HTTPException(status_code=404, detail="Chapter não encontrado")
    if not chapter.pages:
        raise HTTPException(status_code=400, detail="Capítulo não tem páginas")

    try:
        fmt = ExportFormat(payload.format)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Formato inválido: {payload.format}")

    composed_paths = []
    for page in sorted(chapter.pages, key=lambda p: p.page_number):
        if page.status.value != "ready":
            page = page_service.generate_page(page.id, style_profile_id=payload.style_profile_id)
        composed_paths.append(f"./output/pages/page_{page.page_number}.png")

    output_path = export_service.export(chapter, composed_paths, fmt)
    return {
        "chapter_id": chapter.id,
        "pages_exported": len(composed_paths),
        "output_path": output_path,
        "download_url": to_public_url(output_path),
    }


def _imported_file_to_dict(item) -> dict:
    return {
        "id": item.id,
        "original_path": item.original_path,
        "stored_path": to_public_url(item.stored_path),
        "category": item.category.value,
        "status": item.status.value,
        "size_bytes": item.size_bytes,
        "sha256": item.sha256,
        "tags": item.tags,
        "thumbnail_url": to_public_url(item.thumbnail_path),
        "extracted_page_urls": [to_public_url(p) for p in item.extracted_page_paths],
        "style_analysis": dataclasses.asdict(item.style_analysis) if item.style_analysis else None,
        "model_info": dataclasses.asdict(item.model_info) if item.model_info else None,
        "error_message": item.error_message,
    }


@app.post("/import/scan", tags=["import"])
def import_scan(payload: ImportScanRequest):
    """Importa um arquivo único ou varre uma pasta inteira recursivamente
    (conforme a spec: 'pastas completas'). Roda de forma síncrona —
    pra pastas muito grandes, pode demorar; a resposta inclui o resumo
    completo (total, processados, duplicatas, corrompidos, erros,
    velocidade) que a spec pediu pra mostrar na interface."""
    if not os.path.exists(payload.path):
        raise HTTPException(status_code=404, detail=f"Caminho não encontrado: {payload.path}")

    if os.path.isdir(payload.path):
        result = import_pipeline.scan_directory(payload.path)
        return {
            "total_files": result.total_files,
            "processed": result.processed,
            "duplicates": result.duplicates,
            "corrupted": result.corrupted,
            "failed": result.failed,
            "file_ids": result.file_ids,
            "errors": result.errors,
            "elapsed_seconds": result.elapsed_seconds,
            "files_per_second": result.files_per_second,
        }

    item = import_pipeline.import_file(payload.path)
    return _imported_file_to_dict(item)


@app.get("/import/files", tags=["import"])
def list_imported_files(category: str | None = None):
    cat_enum = None
    if category:
        try:
            cat_enum = FileCategory(category)
        except ValueError:
            valid = ", ".join(c.value for c in FileCategory)
            raise HTTPException(status_code=400, detail=f"Categoria inválida: '{category}'. Válidas: {valid}")
    items = import_repo.list(category=cat_enum)
    return [_imported_file_to_dict(item) for item in items]


@app.get("/import/files/{file_id}", tags=["import"])
def get_imported_file(file_id: str):
    item = import_repo.get(file_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Arquivo importado não encontrado")
    return _imported_file_to_dict(item)


@app.get("/hardware", tags=["system"])
def get_hardware():
    """Mostra o que o Hardware Manager detectou e qual perfil o AI
    Optimizer escolheu automaticamente — sem precisar configurar nada."""
    return {
        "cpu_count": detected_system.cpu_count,
        "ram_total_mb": detected_system.ram_total_mb,
        "gpus": [
            {
                "name": g.name,
                "vram_total_mb": g.vram_total_mb,
                "vram_free_mb": g.vram_free_mb,
                "cuda_version": g.cuda_version,
                "driver_version": g.driver_version,
                "compute_capability": g.compute_capability,
                "supports_bf16": g.supports_bf16,
            }
            for g in detected_system.gpus
        ],
        "selected_profile": {
            "name": hardware_profile.name,
            "precision": hardware_profile.precision.value,
            "max_resolution": hardware_profile.max_resolution,
            "default_batch_size": hardware_profile.default_batch_size,
            "max_concurrent_loras": hardware_profile.max_concurrent_loras,
            "cpu_offload": hardware_profile.enable_cpu_offload,
            "quantization": hardware_profile.enable_quantization,
            "multi_model_cache": hardware_profile.enable_multi_model_cache,
            "notes": hardware_profile.notes,
        },
    }


@app.get("/health", tags=["system"])
def health():
    return {
        "status": "ok",
        "pipeline": "mock" if USE_MOCK_PIPELINE else "diffusers",
        "hardware_profile": hardware_profile.name,
    }
